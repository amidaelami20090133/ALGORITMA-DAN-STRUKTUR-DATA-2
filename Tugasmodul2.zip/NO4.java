package Matriks;
public class NO4 {
    public static void main(String[] args){
        int[][] B = {
            {2,1,5},
            {3,4,2}
        };
        int[][] tranpose = new int[6][6];
        for(int i=0; i<B.length; i++) {
                for(int j=0; j<B[0].length; j++){
                    tranpose[j][i] = B[i][j];
                }
                    System.out.println();
        }
        for(int i=0; i < B.length; i++){
            for(int j=0; j<B.length; j++){
                System.out.print(tranpose[i][j]+" ");
            }
            System.out.println();
        }   
        }
    }


