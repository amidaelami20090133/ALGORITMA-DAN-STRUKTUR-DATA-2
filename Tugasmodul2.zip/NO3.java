package Matriks;
public class NO3 {
    public static void main(String[] args){
        int[][] A = {
            {6,7,8},
            {5,3,9}
        };
        
        int[][] B = {
            {6,2},
            {5,3},
            {4,4}
        };
        
            int[][] perkalian = new int [A.length][B.length];
            for(int i=0; i<A.length; i++) {
                for(int j=0; j<B[0].length; j++){
                    perkalian[i][j] = A[i][j] * B[i][j];
                    System.out.print(perkalian[i][j]+ " ");
                }
            }
        }
        for(int[] x: perkalian){
            for(int y: x){
                System.out.print(y+" ");
            }
            System.out.println();
        }
    }

